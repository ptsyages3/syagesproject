<!DOCTYPE html>
<html>
<head>
    <link rel="shortcut icon" href="img/logo.jpg"/>
	<title><?php if(isset($title)){echo $title;} ?></title>
    <link rel="stylesheet" type="text/css" href="/css/general/general.css">
    <link rel="stylesheet" type="text/css" href="/css/general/accueil.css">
    <link rel="stylesheet" type="text/css" href="/css/accueil-partie-mel.css">
    

    