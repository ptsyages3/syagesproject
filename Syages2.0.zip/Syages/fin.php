<footer>
                <ul>
                    <li><a href="mentionsleg.html">Mentions légales</a></li>
                    <li><a href="apropos.html">À Propos - Syages©</a></li>
                    <li><a href="http://ataraxy.xyz/">ATARAXY</a></li>
                </ul>
            </footer>
        </div>
        

    </div>
</body>
</html>
