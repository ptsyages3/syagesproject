<!--body de graphiques utilisables par tous les user-->
<div class="body" id="body">
           
            <div class="melbanner">
            
                <button id="btn-menu1" onclick="show_hide()"><img src="../img/menu.png" id="menu"></button>
                <img src="../img/logo.png" id="logo"/>
                <input type="text" placeholder="Entrez des mots-clés" id="searchbar"><input type="submit" value="Rechercher" id="submitbutton">
                <img src="../img/david.jpg" id="user"/>
            
            </div>
            <div class="page-graph">
                <div class="charts-container">
                    <div class="chart-container" style="position: relative; flex:.5;margin-bottom: 25px;">
                        <canvas id="myChart"></canvas>
                    </div>

                    <div class="chart-container">
                        <canvas id="myChart-2"></canvas>
                    </div>
                    
                </div>
                <p>Bilan : il y a xxx absences constatées au cours de cette semaine dont xxx justifiées et donc xxx injustifiées. Les élèves devant justifier leurs absences sont : implode("select nom from user join absences on absence.iDEtudiant=user.iD and absence.justifie!=true;" , " ") <em>PHP</em><br/><br/></p>
                
                <div class="charts-container">
                    <div class="chart-container">
                        <canvas id="myChart-3"></canvas>
                    </div>

                    <div class="chart-container">
                        <canvas id="myChart-4"></canvas>
                    </div>
                    
                </div>
                <p>Bilan : il y a xxx absences constatées au cours de cette semaine dont xxx justifiées et donc xxx injustifiées. Les élèves devant justifier leurs absences sont : implode("select nom from user join absences on absence.iDEtudiant=user.iD and absence.justifie!=true;" , " ") <em>PHP</em><br/><br/></p>
                
                <div class="charts-container">
                    <div class="chart-container">
                        <canvas id="myChart-5"></canvas>
                    </div>
                     <p>Bilan : il y a xxx absences constatées au cours de cette semaine dont xxx justifiées et donc xxx injustifiées. Les élèves devant justifier leurs absences sont : implode("select nom from user join absences on absence.iDEtudiant=user.iD and absence.justifie!=true;" , " ") <em>PHP</em><br/><br/></p>
                
                    <div class="chart-container">
                        <canvas id="myChart-6"></canvas>
                    </div>
                     <p>Bilan : il y a xxx absences constatées au cours de cette semaine dont xxx justifiées et donc xxx injustifiées. Les élèves devant justifier leurs absences sont : implode("select nom from user join absences on absence.iDEtudiant=user.iD and absence.justifie!=true;" , " ") <em>PHP</em><br/><br/></p>
               </div>
            </div>